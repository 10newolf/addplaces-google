import 'package:flutter/material.dart';
import 'package:search_map_place/search_map_place.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Map Search Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MapSearchPage(),
    );
  }
}

class MapSearchPage extends StatefulWidget {
  @override
  _MapSearchPageState createState() => _MapSearchPageState();
}

class _MapSearchPageState extends State<MapSearchPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: SearchMapPlaceWidget(
      apiKey: 'AIzaSyAP-jNhkCzfIPB3nhimIDVrmILAgAdXRcs',
    )));
  }
}
